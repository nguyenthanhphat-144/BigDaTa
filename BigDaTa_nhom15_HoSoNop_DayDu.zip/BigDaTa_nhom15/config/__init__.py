# Package initializer for config
