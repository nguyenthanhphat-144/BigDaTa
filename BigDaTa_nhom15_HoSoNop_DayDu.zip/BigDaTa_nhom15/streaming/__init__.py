# Package initializer for streaming
